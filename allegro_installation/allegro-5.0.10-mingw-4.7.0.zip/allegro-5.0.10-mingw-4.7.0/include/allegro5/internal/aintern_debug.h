#ifndef __al_included_allegro5_aintern_debug_h
#define __al_included_allegro5_aintern_debug_h

#ifdef __cplusplus
   extern "C" {
#endif


void _al_shutdown_logging(void);


#ifdef __cplusplus
}
#endif

#endif
